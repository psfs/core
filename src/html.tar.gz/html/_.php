<?php
if(!preg_match('/\.[a-zA-Z0-9]{2,4}$/', $_SERVER['REQUEST_URI'])) {
    require_once(realpath(__DIR__.DIRECTORY_SEPARATOR."..".DIRECTORY_SEPARATOR."vendor") . DIRECTORY_SEPARATOR . "autoload.php");
    PSFS\Dispatcher::getInstance()->run();
} else {
    header('HTTP/1.0 404 Not Found');
    exit('File ' . $_SERVER['REQUEST_URI'] . ' not found');
}
